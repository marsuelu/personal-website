import{j as r}from"./index-Byjm7hrW.js";import"./router-ndYPTExO.js";import"./i18n-Dhs0AlZX.js";import"./vendor-DJG_os-6.js";const e=()=>r.jsx("div",{className:"min-h-1vh bg-fuchsia-400",children:"Travel"});export{e as default};
//# sourceMappingURL=Index-Dw9plHqk.js.map
